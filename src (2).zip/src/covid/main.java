package covid;

import javax.swing.JFrame;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   JFrame f = new JFrame();
	        f.setSize(500, 300);
	        f.getContentPane().add(new SampleComponent());
	        f.setVisible(true);
	}

}
